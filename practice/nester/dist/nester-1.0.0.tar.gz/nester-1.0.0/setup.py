from distutils.core import setup

setup(
	name        = 'nester',
	version     = '1.0.0',
	py_modules  = ['nester'],
	author      = 'qjlpython',
	author_email = 'qujin_liang@163.com',
	url          = 'http://www.qujinliang.com',
	description  = 'A simple printer of nested lists',
	)